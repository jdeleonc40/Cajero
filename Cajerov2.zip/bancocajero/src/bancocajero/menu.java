
package bancocajero;

import java.util.Scanner;


public class menu {

    public void menu1() {
        Scanner sc=new Scanner (System.in);
        int flag =0;
        int seleccion = 0;
        do{
            do{
                //Menu
                System.out.println("Ingrese su opcion");
                System.out.println("1. Consulta de Cuenta");
                System.out.println("2. Consulta de Saldo");
                System.out.println("3. Depósito");
                System.out.println("4. Retiro");
                System.out.println("5. Salir");
                seleccion = sc.nextInt();
                
                // Impide que se ingresen valores mayores a 5
                if (seleccion >=1 && seleccion <= 5){
                    flag = 1;
                }else{
                    System.out.println("Opción no disponible");
                }
            } while (flag == 0);
            if (seleccion == 1){
                //
                System.out.println("Aqui va consulta");
                consulta c1=new consulta();
                c1.cons();
              // flag = 2;
            
            } else if ( seleccion == 2){
                //
                System.out.println("Aqui va consulta de saldo");
            } else if (seleccion  == 3){
                //
                System.out.println("Aqui va deposito");
            } else if (seleccion == 4){
                //
                System.out.println("Aqui va retiro");
                
            } else if (seleccion==5){
                //
                System.out.println("=============================================");
                System.out.println("== Gracias por utilizar nuestros servicios ==");
                System.out.println("=============================================");
                flag = 2;
            }
        }while (flag !=2);
        
        
}
}

