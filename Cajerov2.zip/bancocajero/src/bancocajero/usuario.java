/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancocajero;

import java.util.Scanner;


public class usuario extends variables{
    public void us(){
     //declaración de variables
     Scanner sc= new Scanner(System.in);
     int codigo,pin,contador;
     String nombre;
     boolean bloqueo =false;
     contador = 0;
     //bucle de búsqueda del código
     while(!bloqueo){
         //CODIGO
        System.out.print("Ingrese su CODIGO de usuario: ");
        System.out.println(" ");
        codigo = sc.nextInt();
        System.out.println(" ");
        //PIN
        System.out.print("Ingrese su PIN de acceso: ");
        System.out.println(" ");
        pin = sc.nextInt();
        System.out.println(" ");
        
        // Inicia la sentencia de IF
        if (codigo ==1987 && pin ==1415 ){
            System.out.println("\u001B[42;30m Usuario identificado correctamente \u001B[0m");
            nombre="JAMES DE LEON";
            System.out.println("Bienvenido: "+nombre);
            //llama el menú
            menu opc=new menu();
            opc.menu1();
            break;
        }else if (codigo ==1000 && pin ==1234){
            System.out.println("\u001B[42;30m Usuario identificado correctamente \u001B[0m");
            nombre="LUIS CUX";
            System.out.println("Bienvenido: "+nombre);
            menu opc=new menu();
            opc.menu1();
            break;
        }else if (codigo ==2000 && pin ==1010){
            System.out.println("\u001B[42;30m Usuario identificado correctamente \u001B[0m");
            nombre="STIVEN FERNANDEZ";
            System.out.println("Bienvenido: "+nombre);
            menu opc=new menu();
            opc.menu1();
            break;    
 
            
        }else {
            contador=contador+1;
  
        }       
        // Identifica el contador  
        switch (contador){
            case 1:
            System.out.println("Intento número: "+contador);
            System.out.println("\u001B[43;30m El CODIGO/PIN que ingreso es inválido, intente de nuevo.\u001B[0m");
            System.out.println("=========================================================\n ");
            break;      
            case 2:
            System.out.println("Intento número: "+contador);
            System.out.println("\u001B[43;30m El CODIGO/PIN que ingreso es inválido, intente de nuevo.\u001B[0m");
            System.out.println("=========================================================\n ");
            break;
            case 3:
            System.out.println("Intento número: "+contador);
            System.out.println("\u001B[41;37m Usuario BLOQUEADO temporalmente\u001B[41;30m");
            System.out.println("=========================================================\n ");
            bloqueo = true;
            break;
            default:
            
            break;  
        }
        
       /* variables u1=new variables();
        u1.setCodigo(codigo+1);
        System.out.println("el codigo nuevo es "+u1.getCodigo());*/
        
        
        
     }//llave del while
}
    
    
    
}
