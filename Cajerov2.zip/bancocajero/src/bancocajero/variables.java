
package bancocajero;


public class variables {
    private int codigo;
    private int pin;
    private int contador;
    private String nombre;
    

    
    //Método para dar valores a los atributos
    public void setCodigo(int cod){
    codigo=cod;
    }
    //Método para mostrar el valor en cada atributo
    public int  getCodigo(){
        return codigo;
    }

    public void setPin(int pin) {
        this.pin=pin;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }

    public int getPin() {
        return pin;
    }

    public int getContador() {
        return contador;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
        public void mostrarMensaje(){
        System.out.println("Hola");
        
    }


}
