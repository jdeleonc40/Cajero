
package bancocajero;

public class consulta {
    public void cons(){
        System.out.println("Stiven");
        System.out.println("Stiven");
        System.out.println("Stiven");
        System.out.println("Stiven");
        System.out.println("Stiven");
        System.out.println("Stiven");
        
    }
    
}
