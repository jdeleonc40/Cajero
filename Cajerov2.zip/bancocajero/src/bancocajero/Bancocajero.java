package bancocajero;

import java.util.Scanner;

/**
 *
 * @author james
 */
public class Bancocajero {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {
       // Menú de acceso
        System.out.println("=========================");
        System.out.println("==      Banco CLJ      ==");
        System.out.println("=========================\n");

        
        //Variables
        Scanner sc= new Scanner (System.in);
       
        /*login invoca=new login();
        invoca.acceso();
        
        pin invoca2=new pin();
        invoca2.pass();*/
        /*usuario u1=new usuario();
        u1.setNombre("James");
        u1.setCodigo(18);
        u1.mostrarMensaje();
        System.out.println("Ejemplo "+u1.getCodigo());*/
        usuario u2=new usuario();
        u2.us();
        
        

        
        

    }
}
